   
const spotifybot = require('./service/spotifyBot')
spotifybot.playTracks();
console.log(new Date(), 'Start playing tracks... ');