var auth = require('./auth');
var dashboard = require('./dashboard');
var botdashboard = require('./botdashboard');

module.exports = { auth, dashboard, botdashboard };
