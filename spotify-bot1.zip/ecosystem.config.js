module.exports = {
 apps : [{
    name        : "spotifyadmin",
    script      : "./index.js",
    watch       : true,
    error_file : "../log/admin_err.log",
    out_file : "../log/admin_out.log",
  },{
    name       : "spotifybot",
    script     : "./bot.js",
    watch	: true,
    error_file : "../log/bot_error.log",
    out_file : "../log/bot_out.log",
  }]

}
