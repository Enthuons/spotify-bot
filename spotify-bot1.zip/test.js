const auth = {
    username: "info@mobiletheplanet.com",
    password: "###.music.###",
};
const musicUrl = 'https://open.spotify.com/track/4lJNen4SMTIJMahALc3DcB';
const loginUrl = 'https://accounts.spotify.com/en/login/';
let count = 0;

/// ------------------- S T A R T    T E S T    W I T H    G O O G L E - C H R O M E  --------------------

const { Builder, By, Key, until } = require('selenium-webdriver');
const chrome = require('selenium-webdriver/chrome');

start = () => {
    let chromeOptions = new chrome.Options();
    chromeOptions.addArguments("--headless");
    chromeOptions.addArguments("--start-maximized");
    chromeOptions.addArguments("--no-sandbox");

    const driver = new Builder()
        .forBrowser('chrome')
        .setChromeOptions(chromeOptions)
        .build();

    async function init() {
        try {
            if (driver) {
                // ---------------------------------------  YOUTUBE  --------------------------------------------
                // await driver.wait(until.elementLocated(By.id('search-input')));
                await driver.get('https://www.youtube.com/watch?v=WNeLUngb-Xg&list=RDWNeLUngb-Xg&start_radio=1');
                await driver.wait(until.elementLocated(By.className('ytp-left-controls')));
                var body = await driver.findElement(By.tagName("body"));
                body.sendKeys(Key.SPACE);

                // ---------------------- autoPlay --------------------------
                // async function autoPlay() {
                //     try {
                //         console.log('step-1');
                //         var status = await driver.executeScript(() => {
                //             var a = document.querySelectorAll('.ytp-left-controls');
                //             var x = a[0].children[1].getAttribute('title');
                //             if (x == 'Pause (k)') {
                //                 return 'paused';
                //             } else if (x == 'play (k)') {
                //                 return 'play';
                //             } else return 'none';
                //         });
                //         console.log('step-2 : ', status);
                //         if (status === 'paused') {
                //             console.log('step-3 : ', status);
                //             var body = await driver.findElement(By.tagName("body"));
                //             body.sendKeys(Key.SPACE);
                //         }
                //     } catch (e) {
                //         console.log('Error from autoPlay : ', e);
                //     }
                // }
                // var autoPlayInterval = setInterval(autoPlay, 5 * 1000);
                // ----------------------------------------------------------

                // ----------------- Take screenshot ------------------------
                let i = 0;
                screenshot = () => {
                    console.log('take screenshot');
                    i++;
                    driver.takeScreenshot().then(
                        function (image, err) {
                            require('fs').writeFile(`screenshot/test/youtube_out${i}.png`, image, 'base64', function (err) {
                                console.log(err);
                            });
                        }
                    );
                }
                setInterval(screenshot, 5 * 1000);
                // ---------------------------------------------------------

                await driver.sleep(2 * 60 * 1000);

            } else console.log('N');

        } catch (e) {
            console.log('Error in main try/catch : ', e);
        } finally {
            // await clearInterval(play);
            clearInterval(autoPlayInterval);
            await driver.quit();
            count++
            if (count < 2) start();
        }

    }
    init();

}
start();

/// ------------------- E N D    T E S T    W I T H    G O O G L E - C H R O M E  --------------------










/// ------------------- S T A R T    T E S T    W I T H    P U P P E T E E R  --------------------

// const puppeteer = require('puppeteer');

// (async () => {
//   const auth = {
//     username: "info@mobiletheplanet.com",
//     password: "###.music.###",
//   };
//   const musicUrl = 'https://open.spotify.com/track/4lJNen4SMTIJMahALc3DcB';
//   const loginUrl = 'https://accounts.spotify.com/en/login/';

//   const browser = await puppeteer.launch({ headless: false });
//   const page = await browser.newPage();
//   await page.setViewport({ width: 1366, height: 768});

//   // Open login page
//   await page.goto(loginUrl);

//   // Enter username
//   await page.focus('#login-username');
//   await page.keyboard.type(auth.username);

//   // Enter password
//   await page.focus('#login-password');
//   await page.keyboard.type(auth.password);

//   // Click Enter for login
//   await page.keyboard.press('Enter');

//   // Wait for 5 sec for logged in from spotify
//   await page.waitFor(5*1000);

//   // Load music url page
//   await page.goto(musicUrl);

//   await page.waitFor(30*1000);

//   // login-button
//   // await page.evaluate((selector) => document.querySelector(selector).click(), selector); 


//   await page.screenshot({path: 'screenshot/puppeteer/google.png'});

//   await browser.close();
// })();

/// ----------------------- E N D    T E S T    W I T H    P U P P E T E E R  -------------------------






/// ----------------------  S T A R T    T E S T    W I T H    F I R E F O X  -------------------------

// const { Builder, By, Key, until } = require('selenium-webdriver');

// var driver = new Builder()
//     .forBrowser('firefox')
//     .build();

//     async function spotifyFirefox() {
//         await driver.get(loginUrl);
//         await driver.findElement(By.id('login-username')).sendKeys(auth.username);
//         await driver.findElement(By.id('login-password')).sendKeys(auth.password, Key.RETURN);
//         await driver.sleep(5*1000);

//         await driver.get(musicUrl);
//         await driver.sleep(10*1000);

//         await driver.sleep(10*1000);
//         await driver.quit();
//     }
//     spotifyFirefox();

/// ----------------------  E N D   T E S T    W I T H    F I R E F O X  -------------------------





/// ----------------------  S T A R T    T E S T    W I T H    P H A N T O M   J S  -------------------------

// (async function() {
//     const instance = await phantom.create();
//     const page = await instance.createPage();
//     // page.viewportSize = { width: 1024, height: 768 };
//     // page.clipRect = { top: 0, left: 0, width: 1024, height: 768 };


//     await page.on("onResourceRequested", function(requestData) {
//         // console.info('Requesting', requestData.url)
//     });

//     await page.on("onResourceReceived", function(requestData) {
//         // console.info('Receive', requestData.url)
//     });

//     // page.settings.userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36';
//     // await page.settings.userAgent('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36');

//     // page.settings.javascriptEnabled = true;
//     // page.settings.loadImages = false;//Script is much faster with this field set to false
//     // phantom.cookiesEnabled = true;
//     // phantom.javascriptEnabled = true;



//     page.onResourceRequested = function(request) {console.log('Request ' + JSON.stringify(request, undefined, 4));};
//     page.onResourceReceived = function(response) {console.log('Receive ' + JSON.stringify(response, undefined, 4));};



//     let status = await page.open(loginUrl);
//     console.log('login page status___', status);

//     await page.evaluate(function(){
//         document.getElementById("login-username").value=auth.username;
//         document.getElementById("login-password").value=auth.password;
//         document.getElementById("login-button").submit();
//     });

//     status = await page.open(musicUrl);
//     console.log('music url page status___', status);




//     // console.log(status);

//     // const content = await page.property('content');
//     // console.log(content);

//     await instance.exit();
// }());


// var page = require('webpage').create();
//   //viewportSize being the actual size of the headless browser
//   page.viewportSize = { width: 1024, height: 768 };
//   //the clipRect is the portion of the page you are taking a screenshot of
//   page.clipRect = { top: 0, left: 0, width: 1024, height: 768 };
//   //the rest of the code is the same as the previous example
//   page.open('http://example.com/', function() {
//     page.render('github.png');
//     phantom.exit();
//   });


/// ----------------------  E N D   T E S T    W I T H    P H A N T O M   J S  -------------------------
