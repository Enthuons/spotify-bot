/// ------------------- S T A R T    T E S T    W I T H    P U P P E T E E R  --------------------

const puppeteer = require('puppeteer');

(async () => {
    const spotifyAccount = [
        {
            "username": "admin1@knoxweb.com",
            "password": "###.music.###"
        },
        {
            "username": "smokyweb@gmail.com",
            "password": "osmosis123"
        }
    ]
  const spotifyMusicUrl = 'https://open.spotify.com/track/4lJNen4SMTIJMahALc3DcB';
  const youtubeMusicUrl = 'https://www.youtube.com/watch?v=WNeLUngb-Xg&list=RDWNeLUngb-Xg&start_radio=1';
  const soundcloudMusicUrl = 'https://soundcloud.com/nocopyrightsounds/alan-walker-force-ncs-release';
  
  const spotifyLoginUrl = 'https://accounts.spotify.com/en/login/';


//   const browser = await puppeteer.launch({ headless: true, args: ['--start-fullscreen', '--window-size=1920,1040'] });
// const page = await browser.newPage();
// await page.setViewport({ width: 1920, height: 1040 });

  const browser = await puppeteer.launch({ headless: false, args: ['--start-fullscreen', '--window-size=1366,768'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1366, height: 768});

  // Open login page
  await page.goto(spotifyLoginUrl);

  // Enter username
  await page.focus('#login-username');
  await page.keyboard.type(spotifyAccount[1].username);

  // Enter password
  await page.focus('#login-password');
  await page.keyboard.type(spotifyAccount[1].password);

  // Click Enter for login
  await page.keyboard.press('Enter');

  // Wait for 5 sec for logged in from spotify
  await page.waitFor(2*1000);

  // Load music url page
  await page.goto(spotifyMusicUrl);

  await page.waitFor(10*60*1000);

  // login-button
  // await page.evaluate((selector) => document.querySelector(selector).click(), selector); 


  await page.screenshot({path: 'screenshot/puppeteer/google.png'});

  await browser.close();
})();

/// ----------------------- E N D    T E S T    W I T H    P U P P E T E E R  -------------------------

