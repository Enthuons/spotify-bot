let count = 0;
const playRepet = 2;
let screenshotMode = 'normal_mode';  // type `normal_mode` or `headless_mode`

const spotifyMusicUrl = 'https://open.spotify.com/track/4lJNen4SMTIJMahALc3DcB';
const youtubeMusicUrl = 'https://www.youtube.com/watch?v=WNeLUngb-Xg&list=RDWNeLUngb-Xg&start_radio=1';
const soundcloudMusicUrl = 'https://soundcloud.com/nocopyrightsounds/alan-walker-force-ncs-release';

/// ------------------- S T A R T    T E S T    W I T H    G O O G L E - C H R O M E  --------------------

const { Builder, By, Key, until } = require('selenium-webdriver');
const chrome = require('selenium-webdriver/chrome');

start = () => {
    let chromeOptions = new chrome.Options();
    // chromeOptions.addArguments("--headless"); screenshotMode = 'headless_mode';
    chromeOptions.addArguments("--start-maximized");
    chromeOptions.addArguments("--no-sandbox");

    const driver = new Builder()
        .forBrowser('chrome')
        .setChromeOptions(chromeOptions)
        .build();

    async function init() {
        try {
            if (driver) {
                // ---------------------------------------  S O U N D  C L O U D  --------------------------------------------
                // await driver.wait(until.elementLocated(By.id('search-input')));
                await driver.get(soundcloudMusicUrl);
                let playControl = await driver.wait(until.elementLocated(By.className('playControls__elements')));

                // ---------------------- autoPlay --------------------------
                async function autoPlay() {
                    try {
                        if (playControl) {
                            let status = await driver.executeScript(() => {
                                let element = document.querySelectorAll('.playControls__elements');
                                let result = element[0].children[1].getAttribute('aria-label');
                                return result;
                            });
                            if (status === 'Play current') {
                                console.log('music is paused...');
                                let body = await driver.findElement(By.tagName("body"));
                                await body.sendKeys(Key.SPACE);
                            } else if (status === 'Pause current') {
                                console.log('music is playing');
                            } else console.log('none');
                        }
                    } catch (e) {
                        console.log('Error from ___ autoplay : ', e);
                    }
                }
                let autoPlayInterval = setInterval(autoPlay, 5 * 1000);
                // ----------------------------------------------------------


                // ----------------- Take screenshot ------------------------
                let i = 0;
                screenshot = () => {
                    console.log('take screenshot');
                    i++;
                    driver.takeScreenshot().then(
                        function (image, err) {
                            require('fs').writeFile(`screenshot/test/${screenshotMode}/soundcloud/screenshot_${i}.png`, image, 'base64', function (err) {
                                console.log(err);
                            });
                        }
                    );
                }
                setInterval(screenshot, 5 * 1000);
                // ---------------------------------------------------------

                await driver.sleep(1 * 60 * 1000);

            } else console.log('N');

        } catch (e) {
            console.log('Error in main try/catch : ', e);
        } finally {
            clearInterval(autoPlayInterval);
            clearInterval(screenshot);
            await driver.quit();
            count++
            if (count < playRepet) start();
        }

    }
    init();

}
start();

/// ------------------- E N D    T E S T    W I T H    G O O G L E - C H R O M E  --------------------

