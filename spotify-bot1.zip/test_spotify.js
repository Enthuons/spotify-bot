let count = 0;
const playRepet = 2;
let screenshotMode = 'normal_mode';  // type `normal_mode` or `headless_mode`

const spotifyAccount = [
    {
        "username": "admin1@knoxweb.com",
        "password": "###.music.###"
    },
    {
        "username": "smokyweb@gmail.com",
        "password": "osmosis123"
    }
]

const spotifyMusicUrl = 'https://open.spotify.com/track/77TT8Xvx637TpzV8kKGkUw';
const youtubeMusicUrl = 'https://www.youtube.com/watch?v=WNeLUngb-Xg&list=RDWNeLUngb-Xg&start_radio=1';
const soundcloudMusicUrl = 'https://soundcloud.com/nocopyrightsounds/alan-walker-force-ncs-release';

const spotifyLoginUrl = 'https://accounts.spotify.com/en/login/';

/// ------------------- S T A R T    T E S T    W I T H    G O O G L E - C H R O M E  --------------------

const { Builder, By, Key, until } = require('selenium-webdriver');
const chrome = require('selenium-webdriver/firefox');

start = () => {
    let chromeOptions = new chrome.Options();
    chromeOptions.addArguments("--headless"); screenshotMode = 'headless_mode';   // -- conmment/uncomment this line to switch between headless and normal mode 
    chromeOptions.addArguments("--start-maximized");
    chromeOptions.addArguments("--no-sandbox");

    const driver = new Builder()
        .forBrowser('firefox')
        .setChromeOptions(chromeOptions)
        .build();

    async function init() {
        try {
            if (driver) {
                // ---------------------------------------  S P O T I F Y  --------------------------------------------

                // ----------------- Take screenshot ------------------------
                let i = 0;
                screenshot = () => {
                    console.log('take screenshot');
                    i++;
                    driver.takeScreenshot().then(
                        function (image, err) {
                            require('fs').writeFile(`screenshot/test/${screenshotMode}/spotify/screenshot_${i}.png`, image, 'base64', function (err) {
                                console.log(err);
                            });
                        }
                    );
                }
                setInterval(screenshot, 5 * 1000);
                // ---------------------------------------------------------


                await driver.get(spotifyLoginUrl);
                await driver.findElement(By.id('login-username')).sendKeys(spotifyAccount[1].username);
                await driver.findElement(By.id('login-password')).sendKeys(spotifyAccount[1].password, Key.RETURN);
                
                await driver.sleep(3000);
                await driver.get(spotifyMusicUrl);
                let loadPlayer = await driver.wait(until.elementLocated(By.className('playback-bar__progress-time')));

                // ---------------------- autoPlay --------------------------
                async function autoPlay() {
                    try {
                      if (loadPlayer) {
                        var result = await driver.executeScript(() => {
                          var playcontrol_container = document.querySelector(".Root__top-container .player-controls .player-controls__buttons");
                          var pauseTrack = playcontrol_container.querySelectorAll('.spoticon-play-16');
                          var playTrack = playcontrol_container.querySelectorAll('.spoticon-pause-16');
                          return pauseTrack.length > 0 ? 'paused' : playTrack.length > 0 ? 'playing' : 0;
                        });
                        if (result && result === 'paused') {
                          var body = await driver.findElement(By.tagName("body"));
                          body.sendKeys(Key.SPACE);
                        }
                      }
                    } catch (e) {
                      console.log('Error from autoPlay : spotify_bot-', botID, ' -> ', e);
                    }
                  }
                  var autoPlayInterval = setInterval(autoPlay, 5 * 1000);
                // ----------------------------------------------------------

                await driver.sleep(1 * 60 * 1000);

            } else console.log('No browser found!');

        } catch (e) {
            console.log('Error in main try/catch : ', e);
        } finally {
            clearInterval(autoPlayInterval);
            clearInterval(screenshot);
            await driver.quit();
            count++
            if (count < playRepet) start();
        }

    }
    init();

}
start();

/// ------------------- E N D    T E S T    W I T H    G O O G L E - C H R O M E  --------------------

