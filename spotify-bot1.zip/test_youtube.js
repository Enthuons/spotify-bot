let count = 0;
const playRepet = 2;
let screenshotMode = 'normal_mode';  // type `normal_mode` or `headless_mode`

const spotifyMusicUrl = 'https://open.spotify.com/track/4lJNen4SMTIJMahALc3DcB';
const youtubeMusicUrl = 'https://www.youtube.com/watch?v=WNeLUngb-Xg&list=RDWNeLUngb-Xg&start_radio=1';
const soundcloudMusicUrl = 'https://soundcloud.com/nocopyrightsounds/alan-walker-force-ncs-release';

/// ------------------- S T A R T    T E S T    W I T H    G O O G L E - C H R O M E  --------------------

const { Builder, By, Key, until } = require('selenium-webdriver');
const chrome = require('selenium-webdriver/chrome');

start = () => {
    let chromeOptions = new chrome.Options();
    chromeOptions.addArguments("--headless"); screenshotMode = 'headless_mode';
    chromeOptions.addArguments("--start-maximized");
    chromeOptions.addArguments("--no-sandbox");

    const driver = new Builder()
        .forBrowser('chrome')
        .setChromeOptions(chromeOptions)
        .build();

    async function init() {
        try {
            if (driver) {
                // ---------------------------------------  YOUTUBE  --------------------------------------------
                // await driver.wait(until.elementLocated(By.id('search-input')));
                await driver.get(youtubeMusicUrl);
                await driver.wait(until.elementLocated(By.className('ytp-left-controls')));
                var body = await driver.findElement(By.tagName("body"));
                body.sendKeys(Key.SPACE);

                // ---------------------- autoPlay --------------------------
                // async function autoPlay() {
                //     try {
                //         console.log('step-1');
                //         var status = await driver.executeScript(() => {
                //             var a = document.querySelectorAll('.ytp-left-controls');
                //             var x = a[0].children[1].getAttribute('title');
                //             if (x == 'Pause (k)') {
                //                 return 'paused';
                //             } else if (x == 'play (k)') {
                //                 return 'play';
                //             } else return 'none';
                //         });
                //         console.log('step-2 : ', status);
                //         if (status === 'paused') {
                //             console.log('step-3 : ', status);
                //             var body = await driver.findElement(By.tagName("body"));
                //             body.sendKeys(Key.SPACE);
                //         }
                //     } catch (e) {
                //         console.log('Error from autoPlay : ', e);
                //     }
                // }
                // var autoPlayInterval = setInterval(autoPlay, 5 * 1000);
                // ----------------------------------------------------------

                // ----------------- Take screenshot ------------------------
                let i = 0;
                screenshot = () => {
                    console.log('take screenshot');
                    i++;
                    driver.takeScreenshot().then(
                        function (image, err) {
                            require('fs').writeFile(`screenshot/test/${screenshotMode}/youtube/screenshot_${i}.png`, image, 'base64', function (err) {
                                console.log(err);
                            });
                        }
                    );
                }
                setInterval(screenshot, 5 * 1000);
                // ---------------------------------------------------------

                await driver.sleep(2 * 60 * 1000);

            } else console.log('N');

        } catch (e) {
            console.log('Error in main try/catch : ', e);
        } finally {
            // clearInterval(autoPlayInterval);
            clearInterval(screenshot);
            await driver.quit();
            count++
            if (count < 2) start();
        }

    }
    init();

}
start();

/// ------------------- E N D    T E S T    W I T H    G O O G L E - C H R O M E  --------------------

